﻿#region	License
//------------------------------------------------------------------------------------------------
// <License>
//     <Author> $username$ </Author>
//     <Project> $rootnamespace$ </Project>
//     <File> 
//         <Name> $safeitemname$ </Name>
//         <Created> $time$ </Created>
//         <Key> $guid10$ </Key>
//     </File>
//     <Summary>
//         $safeitemname$
//     </Summary>
// <License>
//------------------------------------------------------------------------------------------------
#endregion License

namespace $rootnamespace$
{
	public interface $safeitemname$
{
	}
}

