﻿#region	License
//------------------------------------------------------------------------------------------------
// <License>
//     <Author> $username$ </Author>
//     <Project> $rootnamespace$ </Project>
//     <File> 
//         <Name> $safeitemname$ </Name>
//         <Created> $time$ </Created>
//         <Key> $guid10$ </Key>
//     </File>
//     <Summary>
//         $safeitemname$
//     </Summary>
// <License>
//------------------------------------------------------------------------------------------------
#endregion License

using System;
using System.Diagnostics;
using System.Collections.Generic;
$if$ ($targetframeworkversion$ >= 3.5)using System.Linq;
$endif$using System.Text;
$if$ ($targetframeworkversion$ >= 4.5)using System.Threading.Tasks;
$endif$

namespace $rootnamespace$
{
	public class $safeitemname$
	{
	}
}

